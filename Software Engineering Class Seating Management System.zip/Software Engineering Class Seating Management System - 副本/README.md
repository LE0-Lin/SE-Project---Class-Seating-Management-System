# Class Seating Management System - Setup Guide

## Prerequisites
- Java 17+
- Maven
- Node.js 18+
- MySQL 8.0+

## Database Setup
1. Create a database named `seating_system`.
2. The tables will be automatically created by Spring Boot (JPA) on the first run.
3. (Optional) You can manually run `backend/src/main/resources/schema.sql`.

## Backend Setup
1. Navigate to `backend` directory.
2. Update `src/main/resources/application.properties` with your MySQL credentials.
3. Run the application:
   ```bash
   mvn spring-boot:run
   ```
   The backend will start on `http://localhost:8080`.

## Frontend Setup
1. Navigate to `frontend` directory.
2. Install dependencies (if not already done):
   ```bash
   npm install
   ```
3. Run the development server:
   ```bash
   npm run dev
   ```
   The frontend will start on `http://localhost:5173`.

## Features
- **Dashboard**: View list of classrooms.
- **Seat Grid**: Visual representation of seats.
- **Drag & Drop**: (Prototype) Drag students to move them between seats.
