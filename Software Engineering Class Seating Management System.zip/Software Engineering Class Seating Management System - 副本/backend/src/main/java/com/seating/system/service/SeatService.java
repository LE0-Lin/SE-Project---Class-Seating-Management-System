package com.seating.system.service;

import com.seating.system.entity.SeatAssignment;
import com.seating.system.entity.SeatLayout;
import com.seating.system.repository.SeatAssignmentRepository;
import com.seating.system.repository.SeatLayoutRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatService {
    @Autowired
    private SeatLayoutRepository seatLayoutRepository;

    @Autowired
    private SeatAssignmentRepository seatAssignmentRepository;

    public List<SeatLayout> getLayoutsByClassroom(Long classroomId) {
        return seatLayoutRepository.findByClassroomId(classroomId);
    }

    public SeatLayout getLayout(Long layoutId) {
        return seatLayoutRepository.findById(layoutId).orElseThrow(() -> new RuntimeException("Layout not found"));
    }

    @Transactional
    public SeatLayout createLayout(SeatLayout layout, List<SeatAssignment> assignments) {
        SeatLayout savedLayout = seatLayoutRepository.save(layout);
        for (SeatAssignment assignment : assignments) {
            assignment.setLayout(savedLayout);
            seatAssignmentRepository.save(assignment);
        }
        return savedLayout;
    }

    @Transactional
    public void updateLayout(Long layoutId, List<SeatAssignment> assignments) {
        seatAssignmentRepository.deleteByLayoutId(layoutId);
        SeatLayout layout = getLayout(layoutId);
        for (SeatAssignment assignment : assignments) {
            assignment.setLayout(layout);
            seatAssignmentRepository.save(assignment);
        }
    }

    public List<SeatAssignment> getAssignments(Long layoutId) {
        return seatAssignmentRepository.findByLayoutId(layoutId);
    }

    public void deleteLayout(Long layoutId) {
        seatLayoutRepository.deleteById(layoutId);
    }
}
