package com.seating.system.config;

import com.seating.system.entity.Classroom;
import com.seating.system.entity.Student;
import com.seating.system.repository.ClassroomRepository;
import com.seating.system.repository.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.List;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner initData(StudentRepository studentRepository, ClassroomRepository classroomRepository) {
        return args -> {
            if (classroomRepository.count() == 0) {
                Classroom c1 = new Classroom();
                c1.setName("高一(1)班");
                c1.setRowCount(6);
                c1.setColCount(8);
                classroomRepository.save(c1);

                Classroom c2 = new Classroom();
                c2.setName("高二(3)班");
                c2.setRowCount(5);
                c2.setColCount(6);
                classroomRepository.save(c2);
            }

            if (studentRepository.count() == 0) {
                List<String> names = Arrays.asList(
                        "张三", "李四", "王五", "赵六", "孙七", "周八", "吴九", "郑十",
                        "陈一", "卫二", "蒋三", "沈四", "韩五", "杨六", "朱七", "秦八",
                        "尤九", "许十", "何十一", "吕十二", "施十三", "张十四", "孔十五",
                        "曹十六", "严十七", "华十八", "金十九", "魏二十", "陶二十一", "姜二十二");

                for (int i = 0; i < 30; i++) {
                    Student s = new Student();
                    String name = (i < names.size()) ? names.get(i) : "学生" + String.format("%03d", i + 1);
                    s.setName(name);
                    s.setStudentNumber(String.format("%03d", i + 1));
                    s.setGender(i % 2 == 0 ? "男" : "女");
                    studentRepository.save(s);
                }
            }
        };
    }
}
