package com.seating.system.controller;

import com.seating.system.entity.SeatAssignment;
import com.seating.system.entity.SeatLayout;
import com.seating.system.service.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seats")
@CrossOrigin(origins = "*")
public class SeatController {
    @Autowired
    private SeatService seatService;

    @GetMapping("/layouts/classroom/{classroomId}")
    public List<SeatLayout> getLayoutsByClassroom(@PathVariable Long classroomId) {
        return seatService.getLayoutsByClassroom(classroomId);
    }

    @GetMapping("/layouts/{layoutId}")
    public SeatLayout getLayout(@PathVariable Long layoutId) {
        return seatService.getLayout(layoutId);
    }

    @PostMapping("/layouts")
    public SeatLayout createLayout(@RequestBody LayoutRequest request) {
        return seatService.createLayout(request.getLayout(), request.getAssignments());
    }

    @PutMapping("/layouts/{layoutId}")
    public void updateLayout(@PathVariable Long layoutId, @RequestBody List<SeatAssignment> assignments) {
        seatService.updateLayout(layoutId, assignments);
    }

    @GetMapping("/assignments/{layoutId}")
    public List<SeatAssignment> getAssignments(@PathVariable Long layoutId) {
        return seatService.getAssignments(layoutId);
    }

    @DeleteMapping("/layouts/{layoutId}")
    public void deleteLayout(@PathVariable Long layoutId) {
        seatService.deleteLayout(layoutId);
    }

    // DTO for creating layout with assignments
    public static class LayoutRequest {
        private SeatLayout layout;
        private List<SeatAssignment> assignments;

        public SeatLayout getLayout() {
            return layout;
        }

        public void setLayout(SeatLayout layout) {
            this.layout = layout;
        }

        public List<SeatAssignment> getAssignments() {
            return assignments;
        }

        public void setAssignments(List<SeatAssignment> assignments) {
            this.assignments = assignments;
        }
    }
}
