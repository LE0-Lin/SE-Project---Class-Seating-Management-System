package com.seating.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeatingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeatingSystemApplication.class, args);
	}

}
