<script setup>
import { useRouter, useRoute } from 'vue-router'
import { useSeatStore } from './stores/seatStore'
import { onMounted, computed } from 'vue'

const router = useRouter()
const route = useRoute()
const store = useSeatStore()

onMounted(() => {
  if (!store.currentUser.role && route.name !== 'login') {
    router.push('/login')
  }
})

const roleLabel = computed(() => {
  return store.currentUser.role === 'teacher' ? '教师端' : '学生端'
})

const logout = () => {
  store.setRole(null)
  router.push('/login')
}
</script>

<template>
  <div class="app-container">
    <header class="top-nav" v-if="route.name !== 'login'">
      <div class="logo">
        <span class="logo-icon">🎓</span>
        <h1>班级座位管理系统</h1>
      </div>
      <div class="user-profile" @click="logout" style="cursor: pointer" title="点击退出">
        <span>{{ roleLabel }}</span>
      </div>
    </header>
    <main class="main-content">
      <RouterView />
    </main>
  </div>
</template>

<style scoped>
.app-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.top-nav {
  height: 64px;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(0,0,0,0.05);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2rem;
  position: sticky;
  top: 0;
  z-index: 100;
}

.logo {
  display: flex;
  align-items: center;
  gap: 12px;
}

.logo-icon {
  font-size: 1.5rem;
}

.logo h1 {
  font-size: 1.25rem;
  color: var(--primary-color);
  letter-spacing: -0.025em;
}

.user-profile {
  font-size: 0.875rem;
  color: var(--text-secondary);
  background: #f3f4f6;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
}

.main-content {
  flex: 1;
  padding: 2rem;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
  box-sizing: border-box;
}
</style>
