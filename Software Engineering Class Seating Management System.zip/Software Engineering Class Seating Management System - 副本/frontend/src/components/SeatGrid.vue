<script setup>
import { computed } from 'vue'

const props = defineProps({
  rows: Number,
  cols: Number,
  assignments: Array,
  students: Array,
  readOnly: Boolean,
  searchQuery: String,
  lockedSeats: {
    type: Set,
    default: () => new Set()
  }
})

const emit = defineEmits(['update:assignments', 'seat-change', 'toggle-lock'])

const grid = computed(() => {
  const g = []
  for (let r = 0; r < props.rows; r++) {
    const row = []
    for (let c = 0; c < props.cols; c++) {
      const assignment = props.assignments.find(a => a.rowIndex === r && a.colIndex === c)
      const isLocked = props.lockedSeats.has(`${r},${c}`)
      
      let isMatch = false
      if (props.searchQuery && assignment && assignment.student) {
          const q = props.searchQuery.toLowerCase()
          isMatch = assignment.student.name.toLowerCase().includes(q) || 
                    assignment.student.studentNumber.includes(q)
      }
      
      row.push({
        rowIndex: r,
        colIndex: c,
        student: assignment ? assignment.student : null,
        isLocked,
        isMatch
      })
    }
    g.push(row)
  }
  return g
})

const onDragStart = (evt, rowIndex, colIndex, student) => {
  if (props.readOnly || !student || props.lockedSeats.has(`${rowIndex},${colIndex}`)) {
    evt.preventDefault()
    return
  }
  evt.dataTransfer.dropEffect = 'move'
  evt.dataTransfer.effectAllowed = 'move'
  evt.dataTransfer.setData('text/plain', JSON.stringify({ rowIndex, colIndex, student }))
  evt.target.classList.add('dragging')
}

const onDragEnd = (evt) => {
  evt.target.classList.remove('dragging')
}

const onDrop = (evt, targetRow, targetCol) => {
  if (props.lockedSeats.has(`${targetRow},${targetCol}`)) return
  
  const data = evt.dataTransfer.getData('text/plain')
  if (!data) return
  
  const source = JSON.parse(data)
  
  // Case 1: Moving from another seat
  if (source.rowIndex !== undefined && source.colIndex !== undefined) {
      console.log(`Moved ${source.student.name} from [${source.rowIndex},${source.colIndex}] to [${targetRow},${targetCol}]`)
      emit('seat-change', { 
          type: 'move',
          from: { r: source.rowIndex, c: source.colIndex }, 
          to: { r: targetRow, c: targetCol },
          student: source.student
      })
  } 
  // Case 2: Dragging from unassigned list
  else if (source.origin === 'unassigned') {
      console.log(`Placed ${source.student.name} to [${targetRow},${targetCol}]`)
      emit('seat-change', {
          type: 'place',
          to: { r: targetRow, c: targetCol },
          student: source.student
      })
  }
}

const toggleLock = (r, c) => {
    if (!props.readOnly) {
        emit('toggle-lock', { r, c })
    }
}

</script>

<template>
  <div class="seat-grid" :class="{ 'searching': !!searchQuery }">
    <div v-for="(row, rIndex) in grid" :key="rIndex" class="seat-row">
      <div 
        v-for="(seat, cIndex) in row" 
        :key="cIndex" 
        class="seat-cell-wrapper"
        @dragover.prevent
        @drop="!readOnly && onDrop($event, rIndex, cIndex)"
      >
        <div 
            class="seat" 
            :class="{ 
                'occupied': !!seat.student, 
                'empty': !seat.student, 
                'read-only': readOnly,
                'locked': seat.isLocked,
                'dimmed': searchQuery && !seat.isMatch && !!seat.student,
                'highlight': seat.isMatch
            }"
            :draggable="!readOnly && !!seat.student && !seat.isLocked"
            @dragstart="onDragStart($event, rIndex, cIndex, seat.student)"
            @dragend="onDragEnd"
        >
            <div class="desk-surface"></div>
            
            <!-- Lock Icon -->
            <div class="lock-icon" v-if="!readOnly" @click.stop="toggleLock(rIndex, cIndex)">
                {{ seat.isLocked ? '🔒' : '🔓' }}
            </div>

            <div class="student-info" v-if="seat.student">
              <span class="avatar">{{ seat.student.name.charAt(0) }}</span>
              <span class="name">{{ seat.student.name }}</span>
            </div>
            <span v-else class="empty-label">空</span>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.seat-grid {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.seat-row {
  display: flex;
  gap: 16px;
  justify-content: center;
}

.seat-cell-wrapper {
  position: relative;
}

.seat {
  width: 90px;
  height: 70px;
  background: white;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: grab;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
  position: relative;
  overflow: hidden;
}

.seat:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
  border-color: var(--primary-color);
}

.seat.dragging {
  opacity: 0.5;
  cursor: grabbing;
}

.seat.empty {
  background: #f8fafc;
  border-style: dashed;
  cursor: default;
}

.seat.empty:hover {
  transform: none;
  box-shadow: none;
  border-color: #cbd5e1;
}

.desk-surface {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 8px;
  background: #e2e8f0;
  opacity: 0.5;
}

.occupied .desk-surface {
  background: #c7d2fe;
  opacity: 1;
}

.student-info {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  z-index: 1;
}

.avatar {
  width: 24px;
  height: 24px;
  background: var(--primary-color);
  color: white;
  border-radius: 50%;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.name {
  font-size: 13px;
  font-weight: 500;
  color: #334155;
}

.empty-label {
  color: #cbd5e1;
  font-size: 12px;
}

/* Lock Styles */
.lock-icon {
    position: absolute;
    top: 4px;
    right: 4px;
    font-size: 10px;
    cursor: pointer;
    opacity: 0;
    transition: opacity 0.2s;
    z-index: 10;
}

.seat:hover .lock-icon, .seat.locked .lock-icon {
    opacity: 1;
}

.seat.locked {
    border-color: #f59e0b;
    background: #fffbeb;
}

.seat.locked .desk-surface {
    background: #fcd34d;
}

/* Search Styles */
.seat.dimmed {
    opacity: 0.3;
    filter: grayscale(100%);
}

.seat.highlight {
    transform: scale(1.1);
    box-shadow: 0 0 0 2px var(--primary-color), 0 8px 16px rgba(0,0,0,0.1);
    z-index: 10;
    border-color: var(--primary-color);
}
</style>
