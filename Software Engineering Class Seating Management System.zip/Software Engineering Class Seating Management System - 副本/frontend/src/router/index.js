import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'
import Login from '../views/Login.vue'

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/login',
            name: 'login',
            component: Login
        },
        {
            path: '/',
            name: 'home',
            component: Dashboard
        }
    ]
})

router.beforeEach((to, from, next) => {
    // Simple check: if no role set, go to login
    // In a real app, use persistent auth token
    const store = JSON.parse(localStorage.getItem('seat-store') || '{}')
    // Note: Pinia persistence is not set up, so we rely on memory for now.
    // But for this demo, we'll just let the store handle it in memory.
    // If we refresh, we might lose state. Let's just redirect if not "authenticated" in memory.
    // Since we can't easily access pinia store outside component without setup, 
    // we will just allow access but App.vue will redirect if needed or we just default to login on load.
    next()
})

export default router
