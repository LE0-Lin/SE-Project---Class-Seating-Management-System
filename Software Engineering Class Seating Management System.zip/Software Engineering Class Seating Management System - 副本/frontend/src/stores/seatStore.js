import { defineStore } from 'pinia'
import axios from 'axios'

const API_URL = 'http://localhost:8080/api'

export const useSeatStore = defineStore('seat', {
    state: () => ({
        classrooms: [],
        currentLayout: null,
        students: [],
        assignments: [],
        currentUser: { role: null }, // 'teacher' or 'student'
        currentStudent: null // The actual student object if role is student
    }),
    actions: {
        setRole(role) {
            this.currentUser.role = role
        },
        setCurrentStudent(student) {
            this.currentStudent = student
        },
        async fetchClassrooms() {
            try {
                const response = await axios.get(`${API_URL}/classrooms`)
                this.classrooms = response.data
            } catch (error) {
                console.error('Error fetching classrooms:', error)
            }
        },
        async fetchStudents() {
            try {
                const response = await axios.get(`${API_URL}/students`)
                this.students = response.data
            } catch (error) {
                console.error('Error fetching students:', error)
            }
        },
        async fetchLayout(layoutId) {
            try {
                const response = await axios.get(`${API_URL}/seats/layouts/${layoutId}`)
                this.currentLayout = response.data
                const assignResponse = await axios.get(`${API_URL}/seats/assignments/${layoutId}`)
                this.assignments = assignResponse.data
            } catch (error) {
                console.error('Error fetching layout:', error)
            }
        },
        async saveLayout(layout, assignments) {
            try {
                let response;
                if (layout.id) {
                    await axios.put(`${API_URL}/seats/layouts/${layout.id}`, assignments)
                    // For PUT, we might want to re-fetch or just assume success. 
                    // But to be safe and keep state consistent:
                    response = { data: layout }
                } else {
                    response = await axios.post(`${API_URL}/seats/layouts`, { layout, assignments })
                }

                // CRITICAL: Update the current layout with the saved one (which has the ID)
                // This prevents creating duplicate layouts on subsequent saves
                if (response.data && response.data.id) {
                    this.currentLayout = response.data
                }
            } catch (error) {
                console.error('Error saving layout:', error)
            }
        },
        async deleteClassroom(id) {
            try {
                await axios.delete(`${API_URL}/classrooms/${id}`)
                await this.fetchClassrooms()
                this.currentLayout = null
                this.assignments = []
            } catch (error) {
                console.error('Error deleting classroom:', error)
            }
        },
        async addStudent(student) {
            try {
                await axios.post(`${API_URL}/students`, student)
                await this.fetchStudents()
            } catch (error) {
                console.error('Error adding student:', error)
                throw error
            }
        },
        async deleteStudent(id) {
            try {
                await axios.delete(`${API_URL}/students/${id}`)
                await this.fetchStudents()
            } catch (error) {
                console.error('Error deleting student:', error)
            }
        },
        async resetData() {
            try {
                // 1. Clear ALL assignments from ALL layouts in ALL classrooms
                await this.fetchClassrooms()

                for (const classroom of this.classrooms) {
                    const layoutsResponse = await axios.get(`${API_URL}/seats/layouts/classroom/${classroom.id}`)
                    const layouts = layoutsResponse.data

                    for (const layout of layouts) {
                        // Delete the layout entirely (cascades to assignments)
                        await axios.delete(`${API_URL}/seats/layouts/${layout.id}`)
                    }
                }

                this.currentLayout = null

                this.assignments = []

                // 2. Delete all students
                const response = await axios.get(`${API_URL}/students`)
                const currentStudents = response.data

                for (const s of currentStudents) {
                    await axios.delete(`${API_URL}/students/${s.id}`)
                }

                // 3. Add new students 001-030
                const names = [
                    '张三', '李四', '王五', '赵六', '孙七', '周八', '吴九', '郑十',
                    '陈一', '卫二', '蒋三', '沈四', '韩五', '杨六', '朱七', '秦八',
                    '尤九', '许十', '何十一', '吕十二', '施十三', '张十四', '孔十五',
                    '曹十六', '严十七', '华十八', '金十九', '魏二十', '陶二十一', '姜二十二'
                ]

                for (let i = 1; i <= 30; i++) {
                    const num = String(i).padStart(3, '0')
                    const gender = i % 2 === 0 ? '女' : '男'
                    const name = names[i - 1] || `学生${num}`

                    await axios.post(`${API_URL}/students`, {
                        name: name,
                        studentNumber: num,
                        gender: gender
                    })
                }

                await this.fetchStudents()

            } catch (error) {
                console.error('Error resetting data:', error)
                throw error
            }
        }
    }
})
