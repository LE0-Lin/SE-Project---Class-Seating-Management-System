<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useSeatStore } from '../stores/seatStore'

const router = useRouter()
const store = useSeatStore()

const username = ref('')
const password = ref('')
const errorMsg = ref('')

const handleLogin = async () => {
  if (username.value === 'admin' && password.value === '123') {
    store.setRole('teacher')
    store.setCurrentStudent(null)
    router.push('/')
  } else {
    // Try to find student by studentNumber
    // Ensure we have students loaded (in a real app this would be a backend call)
    if (store.students.length === 0) {
        await store.fetchStudents()
    }
    
    const student = store.students.find(s => s.studentNumber === username.value)
    
    if (student && password.value === '123') {
        store.setRole('student')
        store.setCurrentStudent(student)
        router.push('/')
    } else {
        errorMsg.value = '用户名或密码错误 (提示: admin/123 或 学号/123)'
    }
  }
}
</script>

<template>
  <div class="login-container">
    <div class="login-card">
      <div class="icon-wrapper">
        <span class="icon">🎓</span>
      </div>
      <h1>欢迎使用</h1>
      <p class="subtitle">班级座位管理系统</p>
      
      <div class="login-form">
        <div class="form-group">
          <input v-model="username" type="text" placeholder="用户名" @keyup.enter="handleLogin" />
        </div>
        <div class="form-group">
          <input v-model="password" type="password" placeholder="密码" @keyup.enter="handleLogin" />
        </div>
        <div class="error-msg" v-if="errorMsg">{{ errorMsg }}</div>
        
        <button class="login-btn" @click="handleLogin">
          登录
        </button>
        
        <div class="tips">
          <p>教师账号: admin / 123</p>
          <p>学生账号: 学号(001-999) / 123</p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-container {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #e0e7ff 0%, #f3f4f6 100%);
}

.login-card {
  background: white;
  padding: 3rem;
  border-radius: 24px;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  width: 100%;
  max-width: 400px;
  text-align: center;
}

.icon-wrapper {
  width: 80px;
  height: 80px;
  background: #eef2ff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
}

.icon {
  font-size: 40px;
}

h1 {
  font-size: 2rem;
  color: #111827;
  margin-bottom: 0.5rem;
}

.subtitle {
  color: #6b7280;
  margin-bottom: 2rem;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-group input {
  width: 100%;
  padding: 1rem;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  font-size: 1rem;
  outline: none;
  transition: all 0.2s;
  box-sizing: border-box;
}

.form-group input:focus {
  border-color: #4f46e5;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
}

.login-btn {
  background: #4f46e5;
  color: white;
  padding: 1rem;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 0.5rem;
}

.login-btn:hover {
  background: #4338ca;
  transform: translateY(-1px);
  box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2);
}

.error-msg {
  color: #ef4444;
  font-size: 0.875rem;
  text-align: left;
}

.tips {
  margin-top: 1.5rem;
  padding-top: 1.5rem;
  border-top: 1px solid #f3f4f6;
  font-size: 0.875rem;
  color: #9ca3af;
  text-align: left;
}

.tips p {
  margin: 0.25rem 0;
}
</style>
