<script setup>
import { onMounted, ref, computed, watch } from 'vue'
import { useSeatStore } from '../stores/seatStore'
import SeatGrid from '../components/SeatGrid.vue'
import axios from 'axios'

const store = useSeatStore()
const selectedClassroom = ref(null)
const showCreateModal = ref(false)
const showStudentModal = ref(false)
const showRequestModal = ref(false)
const requestReason = ref('')
const newClassroom = ref({ name: '', rowCount: 6, colCount: 8 })
const newStudent = ref({ name: '', studentNumber: '', gender: '男' })

// Advanced Features State
const searchQuery = ref('')
const lockedSeats = ref(new Set())

// Student Features State
const mySeat = ref(null)

onMounted(async () => {
  await store.fetchClassrooms()
  await store.fetchStudents()
})

const selectClassroom = async (classroom) => {
    selectedClassroom.value = classroom
    await store.fetchLayout(classroom.id)
    lockedSeats.value.clear()
    searchQuery.value = ''
    
    // If student, check if they have a seat here
    if (!isTeacher.value && store.currentStudent) {
        const assignment = store.assignments.find(a => a.student.id === store.currentStudent.id)
        mySeat.value = assignment ? { r: assignment.rowIndex, c: assignment.colIndex } : null
    }
}

const openCreateModal = () => {
  showCreateModal.value = true
}

const createClassroom = async () => {
  if (!newClassroom.value.name) return
  try {
    const API_URL = 'http://localhost:8080/api'
    await axios.post(`${API_URL}/classrooms`, newClassroom.value)
    await store.fetchClassrooms()
    showCreateModal.value = false
    newClassroom.value = { name: '', rowCount: 6, colCount: 8 }
  } catch (e) {
    console.error(e)
  }
}

const deleteClassroom = async () => {
  if (!selectedClassroom.value) return
  if (confirm(`确定要删除 ${selectedClassroom.value.name} 吗？`)) {
    await store.deleteClassroom(selectedClassroom.value.id)
    selectedClassroom.value = null
  }
}

const addStudent = async () => {
  if (!newStudent.value.name || !newStudent.value.studentNumber) return
  try {
    await store.addStudent(newStudent.value)
    newStudent.value = { name: '', studentNumber: '', gender: '男' }
  } catch (e) {
    alert('添加失败，可能是学号重复')
  }
}

const deleteStudent = async (id) => {
  if (confirm('确定要删除该学生吗？')) {
    await store.deleteStudent(id)
  }
}

// --- Placement Logic ---

const unassignedStudents = computed(() => {
    if (!store.students) return []
    const assignedIds = store.assignments.map(a => a.student.id)
    return store.students.filter(s => !assignedIds.includes(s.id))
})

const onDragStartUnassigned = (evt, student) => {
    evt.dataTransfer.effectAllowed = 'move'
    evt.dataTransfer.setData('text/plain', JSON.stringify({ 
        origin: 'unassigned',
        student: student 
    }))
}

const handleSeatChange = async (event) => {
    let newAssignments = [...store.assignments]
    
    if (event.type === 'place') {
        if (lockedSeats.value.has(`${event.to.r},${event.to.c}`)) return

        newAssignments = newAssignments.filter(a => !(a.rowIndex === event.to.r && a.colIndex === event.to.c))
        newAssignments.push({
            rowIndex: event.to.r,
            colIndex: event.to.c,
            student: event.student
        })
    } else if (event.type === 'move') {
        if (lockedSeats.value.has(`${event.to.r},${event.to.c}`) || 
            lockedSeats.value.has(`${event.from.r},${event.from.c}`)) return

        const targetAssignment = newAssignments.find(a => a.rowIndex === event.to.r && a.colIndex === event.to.c)
        const sourceAssignment = newAssignments.find(a => a.rowIndex === event.from.r && a.colIndex === event.from.c)
        
        if (sourceAssignment) {
            sourceAssignment.rowIndex = event.to.r
            sourceAssignment.colIndex = event.to.c
        }
        
        if (targetAssignment) {
            targetAssignment.rowIndex = event.from.r
            targetAssignment.colIndex = event.from.c
        }
    }
    
    store.assignments = newAssignments
    const layout = store.currentLayout || { name: '默认布局', classroom: { id: selectedClassroom.value.id } }
    await store.saveLayout(layout, newAssignments)
}

const autoAssign = async () => {
    if (!unassignedStudents.value.length) {
        alert('没有待分配的学生！')
        return
    }
    
    if (!confirm('确定要随机填充所有空位吗？（锁定的座位不会变动）')) return
    
    const emptySeats = []
    for (let r = 0; r < selectedClassroom.value.rowCount; r++) {
        for (let c = 0; c < selectedClassroom.value.colCount; c++) {
            if (lockedSeats.value.has(`${r},${c}`)) continue

            const isOccupied = store.assignments.some(a => a.rowIndex === r && a.colIndex === c)
            if (!isOccupied) {
                emptySeats.push({ r, c })
            }
        }
    }
    
    for (let i = emptySeats.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [emptySeats[i], emptySeats[j]] = [emptySeats[j], emptySeats[i]];
    }
    
    const studentsToAssign = [...unassignedStudents.value]
    const newAssignments = [...store.assignments]
    
    while (emptySeats.length > 0 && studentsToAssign.length > 0) {
        const seat = emptySeats.pop()
        const student = studentsToAssign.pop()
        newAssignments.push({
            rowIndex: seat.r,
            colIndex: seat.c,
            student: student
        })
    }
    
    store.assignments = newAssignments
    const layout = store.currentLayout || { name: '默认布局', classroom: { id: selectedClassroom.value.id } }
    await store.saveLayout(layout, newAssignments)
}

const resetLayout = async () => {
    if (!store.assignments.length) return
    if (!confirm('确定要清空座位安排吗？（锁定的座位将保留）')) return
    
    const keptAssignments = store.assignments.filter(a => lockedSeats.value.has(`${a.rowIndex},${a.colIndex}`))
    
    store.assignments = keptAssignments
    const layout = store.currentLayout || { name: '默认布局', classroom: { id: selectedClassroom.value.id } }
    await store.saveLayout(layout, keptAssignments)
}

const onDropToUnassigned = async (evt) => {
    const data = evt.dataTransfer.getData('text/plain')
    if (!data) return
    
    const source = JSON.parse(data)
    
    if (source.rowIndex !== undefined && source.colIndex !== undefined) {
        if (lockedSeats.value.has(`${source.rowIndex},${source.colIndex}`)) return

        const newAssignments = store.assignments.filter(a => !(a.rowIndex === source.rowIndex && a.colIndex === source.colIndex))
        store.assignments = newAssignments
        
        const layout = store.currentLayout || { name: '默认布局', classroom: { id: selectedClassroom.value.id } }
        await store.saveLayout(layout, newAssignments)
    }
}

const toggleLock = ({ r, c }) => {
    const key = `${r},${c}`
    if (lockedSeats.value.has(key)) {
        lockedSeats.value.delete(key)
    } else {
        lockedSeats.value.add(key)
    }
}

const handlePrint = () => {
    window.print()
}

// Student Features
const findMySeat = () => {
    if (mySeat.value) {
        // Highlight logic handled by searchQuery for simplicity, or we can add a specific prop
        // Let's use searchQuery to highlight the student's name
        searchQuery.value = store.currentStudent.name
    } else {
        alert('您在当前班级暂无座位安排。')
    }
}

const submitRequest = () => {
    if (!requestReason.value) return
    alert('申请已提交！老师审核后会通知您。')
    showRequestModal.value = false
    requestReason.value = ''
}

const isResetting = ref(false)

const handleResetData = async () => {
  if (!confirm('确定要重置所有数据吗？这将删除所有现有学生并生成 001-030 号新学生，且会清空当前座位安排。')) return
  
  isResetting.value = true
  try {
    await store.resetData()
    alert('数据重置成功！')
    showStudentModal.value = false
  } catch (error) {
    alert('重置失败，请检查控制台日志。')
  } finally {
    isResetting.value = false
  }
}

const isTeacher = computed(() => store.currentUser.role === 'teacher')
</script>

<template>
  <div class="dashboard-grid">
    <!-- Sidebar -->
    <aside class="sidebar card">
      <div class="sidebar-header">
        <h3>班级列表</h3>
        <div class="sidebar-actions" v-if="isTeacher">
            <button class="icon-btn" @click="showStudentModal = true" title="学生管理">👥</button>
            <button class="add-btn" @click="openCreateModal" title="新建班级">+</button>
        </div>
      </div>
      <ul class="class-list">
        <li 
          v-for="c in store.classrooms" 
          :key="c.id" 
          @click="selectClassroom(c)"
          :class="{ active: selectedClassroom?.id === c.id }"
        >
          <span class="class-icon">🏫</span>
          <span class="class-name">{{ c.name }}</span>
          <span class="student-count">{{ c.rowCount * c.colCount }}座</span>
        </li>
      </ul>
    </aside>

    <!-- Main Content -->
    <section class="content-area card">
      <div v-if="selectedClassroom" class="workspace-wrapper">
        <div class="workspace">
            <header class="workspace-header">
            <div class="header-left">
                <h2>{{ selectedClassroom.name }}</h2>
                <div class="search-box" v-if="isTeacher">
                    <span class="search-icon">🔍</span>
                    <input v-model="searchQuery" placeholder="查找学生..." />
                </div>
                <!-- Student Info -->
                <div class="student-status" v-if="!isTeacher && store.currentStudent">
                    <span class="status-badge">👤 {{ store.currentStudent.name }}</span>
                </div>
            </div>
            <div class="header-actions" v-if="isTeacher">
                <button class="btn btn-secondary" @click="handlePrint" title="打印/导出PDF">📷 导出</button>
                <button class="btn btn-secondary" @click="autoAssign">⚡ 随机</button>
                <button class="btn btn-secondary" @click="resetLayout">🔄 重置</button>
                <button class="btn btn-danger" @click="deleteClassroom">删除</button>
            </div>
            <div class="header-actions" v-else>
                <button class="btn btn-primary" @click="findMySeat">📍 我的座位</button>
                <button class="btn btn-secondary" @click="showRequestModal = true">🙋‍♂️ 申请换座</button>
            </div>
            </header>
            
            <div class="seat-map-container">
            <div class="podium">讲台</div>
            <SeatGrid 
                :rows="selectedClassroom.rowCount" 
                :cols="selectedClassroom.colCount" 
                :assignments="store.assignments"
                :students="store.students"
                :read-only="!isTeacher"
                :search-query="searchQuery"
                :locked-seats="lockedSeats"
                @seat-change="handleSeatChange"
                @toggle-lock="toggleLock"
            />
            </div>
        </div>

        <!-- Unassigned Students Sidebar (Right) -->
        <div 
            class="unassigned-sidebar" 
            v-if="isTeacher"
            @dragover.prevent
            @drop="onDropToUnassigned"
        >
            <div class="unassigned-header">
                <h4>待分配 ({{ unassignedStudents.length }})</h4>
                <span class="hint-text">拖拽学生回此处退座</span>
            </div>
            <div class="unassigned-list">
                <div 
                    v-for="s in unassignedStudents" 
                    :key="s.id"
                    class="student-card"
                    draggable="true"
                    @dragstart="onDragStartUnassigned($event, s)"
                >
                    <span class="avatar-sm">{{ s.name.charAt(0) }}</span>
                    <span class="name">{{ s.name }}</span>
                </div>
                <div v-if="unassignedStudents.length === 0" class="empty-tip">
                    所有学生已入座
                </div>
            </div>
        </div>
      </div>
      
      <div v-else class="empty-state">
        <div class="empty-icon">👈</div>
        <h3>请选择一个班级</h3>
        <p>从左侧列表选择班级以查看座位</p>
      </div>
    </section>

    <!-- Create Modal -->
    <div class="modal-overlay" v-if="showCreateModal" @click.self="showCreateModal = false">
      <div class="modal">
        <h3>创建新班级</h3>
        <div class="form-group">
          <label>班级名称</label>
          <input v-model="newClassroom.name" placeholder="例如：高三(2)班" />
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>行数</label>
            <input type="number" v-model="newClassroom.rowCount" min="1" max="20" />
          </div>
          <div class="form-group">
            <label>列数</label>
            <input type="number" v-model="newClassroom.colCount" min="1" max="20" />
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn btn-secondary" @click="showCreateModal = false">取消</button>
          <button class="btn btn-primary" @click="createClassroom">创建</button>
        </div>
      </div>
    </div>

    <!-- Student Management Modal -->
    <div class="modal-overlay" v-if="showStudentModal" @click.self="showStudentModal = false">
      <div class="modal wide-modal">
        <div class="modal-header">
            <h3>学生管理</h3>
            <button class="close-btn" @click="showStudentModal = false">×</button>
        </div>
        
        <div class="add-student-form">
            <input v-model="newStudent.name" placeholder="姓名" class="input-sm" />
            <input v-model="newStudent.studentNumber" placeholder="学号" class="input-sm" />
            <select v-model="newStudent.gender" class="input-sm">
                <option value="男">男</option>
                <option value="女">女</option>
            </select>
            <button class="btn btn-primary btn-sm" @click="addStudent">添加</button>
        </div>

        <div class="student-list-container">
            <table class="student-table">
                <thead>
                    <tr>
                        <th>学号</th>
                        <th>姓名</th>
                        <th>性别</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="s in store.students" :key="s.id">
                        <td>{{ s.studentNumber }}</td>
                        <td>{{ s.name }}</td>
                        <td>{{ s.gender }}</td>
                        <td>
                            <button class="text-btn danger" @click="deleteStudent(s.id)">删除</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="modal-actions" style="margin-top: 20px; border-top: 1px solid #eee; padding-top: 20px;">
            <button class="btn btn-danger" @click="handleResetData" :disabled="isResetting">
                {{ isResetting ? '重置中...' : '一键重置数据 (001-030)' }}
            </button>
        </div>
      </div>
    </div>

    <!-- Request Seat Change Modal -->
    <div class="modal-overlay" v-if="showRequestModal" @click.self="showRequestModal = false">
      <div class="modal">
        <h3>申请换座</h3>
        <div class="form-group">
          <label>申请理由</label>
          <textarea 
            v-model="requestReason" 
            placeholder="例如：视力不好看不清黑板，希望能调到前排..." 
            rows="4"
            class="textarea-input"
          ></textarea>
        </div>
        <div class="modal-actions">
          <button class="btn btn-secondary" @click="showRequestModal = false">取消</button>
          <button class="btn btn-primary" @click="submitRequest">提交申请</button>
        </div>
      </div>
    </div> 
  </div>
</template>

<style scoped>
.dashboard-grid {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 24px;
  height: calc(100vh - 120px);
}

.card {
  background: var(--card-bg);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-md);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

/* Sidebar Styles */
.sidebar-header {
  padding: 1.5rem;
  border-bottom: 1px solid #f3f4f6;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.sidebar-actions {
    display: flex;
    gap: 8px;
}

.add-btn, .icon-btn {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: #eff6ff;
  color: var(--primary-color);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  transition: all 0.2s;
  border: none;
  cursor: pointer;
}

.icon-btn {
    font-size: 1rem;
    background: #f3f4f6;
    color: #6b7280;
}

.add-btn:hover {
  background: var(--primary-color);
  color: white;
}

.icon-btn:hover {
    background: #e5e7eb;
    color: #374151;
}

.class-list {
  list-style: none;
  padding: 1rem;
  margin: 0;
  overflow-y: auto;
}

.class-list li {
  padding: 12px;
  border-radius: var(--radius-md);
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 12px;
  transition: all 0.2s;
  color: var(--text-secondary);
  margin-bottom: 4px;
}

.class-list li:hover {
  background: #f9fafb;
  color: var(--text-main);
}

.class-list li.active {
  background: #eef2ff;
  color: var(--primary-color);
  font-weight: 500;
}

.student-count {
  margin-left: auto;
  font-size: 0.75rem;
  background: white;
  padding: 2px 6px;
  border-radius: 4px;
  box-shadow: var(--shadow-sm);
}

/* Content Area Styles */
.workspace-wrapper {
    display: flex;
    height: 100%;
}

.workspace {
  display: flex;
  flex-direction: column;
  height: 100%;
  flex: 1;
}

.workspace-header {
  padding: 1.5rem 2rem;
  border-bottom: 1px solid #f3f4f6;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 20px;
}

.search-box {
    display: flex;
    align-items: center;
    background: #f1f5f9;
    padding: 6px 12px;
    border-radius: 20px;
    width: 200px;
    transition: all 0.2s;
}

.search-box:focus-within {
    background: white;
    box-shadow: 0 0 0 2px var(--primary-color);
    width: 240px;
}

.search-icon {
    font-size: 14px;
    margin-right: 8px;
    color: #94a3b8;
}

.search-box input {
    border: none;
    background: transparent;
    outline: none;
    font-size: 14px;
    width: 100%;
}

.student-status {
    background: #eef2ff;
    color: var(--primary-color);
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.875rem;
    font-weight: 500;
}

.subtitle {
  font-size: 0.875rem;
  color: var(--text-secondary);
  margin-top: 4px;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.btn {
  padding: 0.5rem 1rem;
  border-radius: var(--radius-md);
  font-size: 0.875rem;
  font-weight: 500;
  transition: all 0.2s;
}

.btn-primary {
  background: var(--primary-color);
  color: white;
}

.btn-primary:hover {
  background: var(--primary-hover);
  box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
}

.btn-secondary {
  background: white;
  border: 1px solid #d1d5db;
  color: var(--text-main);
}

.btn-secondary:hover {
  background: #f9fafb;
}

.btn-danger {
    background: #fee2e2;
    color: #ef4444;
}

.btn-danger:hover {
    background: #fecaca;
}

.seat-map-container {
  flex: 1;
  background: #f8fafc;
  padding: 2rem;
  overflow: auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
}

.podium {
  width: 200px;
  height: 40px;
  background: #e2e8f0;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #64748b;
  font-weight: 600;
  margin-bottom: 3rem;
  box-shadow: inset 0 -2px 4px rgba(0,0,0,0.05);
}

.empty-state {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
}

.empty-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateX(0); }
  50% { transform: translateX(-10px); }
}

/* Unassigned Sidebar */
.unassigned-sidebar {
    width: 200px;
    border-left: 1px solid #f3f4f6;
    background: white;
    display: flex;
    flex-direction: column;
}

.unassigned-header {
    padding: 1rem;
    border-bottom: 1px solid #f3f4f6;
    color: #374151;
}

.unassigned-header h4 {
    margin: 0;
    font-size: 0.875rem;
    font-weight: 600;
}

.hint-text {
    display: block;
    font-size: 0.75rem;
    color: #9ca3af;
    margin-top: 4px;
}

.unassigned-list {
    flex: 1;
    overflow-y: auto;
    padding: 1rem;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.student-card {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    cursor: grab;
    transition: all 0.2s;
}

.student-card:hover {
    border-color: var(--primary-color);
    background: #eef2ff;
}

.avatar-sm {
    width: 24px;
    height: 24px;
    background: #cbd5e1;
    color: white;
    border-radius: 50%;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.empty-tip {
    text-align: center;
    color: #9ca3af;
    font-size: 0.875rem;
    margin-top: 2rem;
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
}

.modal {
  background: white;
  padding: 2rem;
  border-radius: 16px;
  width: 400px;
  box-shadow: var(--shadow-lg);
}

.wide-modal {
    width: 600px;
    max-height: 80vh;
    display: flex;
    flex-direction: column;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.close-btn {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #9ca3af;
}

.modal h3 {
  margin: 0;
  font-size: 1.25rem;
}

.form-group {
  margin-bottom: 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
  font-weight: 500;
}

.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-family: inherit;
  box-sizing: border-box;
}

.textarea-input {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-family: inherit;
    box-sizing: border-box;
    resize: vertical;
}

.form-row {
  display: flex;
  gap: 1rem;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 2rem;
}

/* Student Management Styles */
.add-student-form {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid #f3f4f6;
}

.input-sm {
    padding: 8px 12px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 0.875rem;
}

.btn-sm {
    padding: 8px 16px;
}

.student-list-container {
    overflow-y: auto;
    flex: 1;
}

.student-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.875rem;
}

.student-table th {
    text-align: left;
    padding: 10px;
    background: #f9fafb;
    color: #6b7280;
    font-weight: 500;
}

.student-table td {
    padding: 10px;
    border-bottom: 1px solid #f3f4f6;
}

.text-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 0.875rem;
}

.text-btn.danger {
    color: #ef4444;
}

.text-btn.danger:hover {
    text-decoration: underline;
}

/* Print Styles */
@media print {
    .sidebar, .header-actions, .unassigned-sidebar, .search-box, .subtitle, .student-status {
        display: none !important;
    }
    
    .dashboard-grid {
        display: block;
        height: auto;
    }
    
    .card {
        box-shadow: none;
        border: none;
    }
    
    .workspace-header {
        justify-content: center;
        border-bottom: none;
    }
    
    .seat-map-container {
        background: white;
        overflow: visible;
    }
    
    .podium {
        border: 1px solid #ccc;
    }
}
</style>
